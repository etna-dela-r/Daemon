.deb package sources
====================

Here are the sources used to build the .deb package.

To do so on your own, download the 'shunt' directory and run

   dpkg-deb --build /path/to/shunt/
