#!/bin/sh

echo "Lancement du daemon Shunt"
