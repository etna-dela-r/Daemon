#!/bin/sh

echo "Arret du daemon Shunt"
